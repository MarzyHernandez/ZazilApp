package com.chr.tarea5.viewmodel

import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateListOf
import com.chr.tarea5.model.Country
import com.chr.tarea5.model.RetrofitInstance
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * ViewModel que maneja la lógica y los datos de los países en la aplicación.
 * @author Carlos Herrera
 */
class ViewModelPaises : ViewModel() {
    private val _countries = mutableStateListOf<Country>()
    val countries: List<Country> get() = _countries

    init {
        fetchCountries()
    }

    private fun fetchCountries() {
        viewModelScope.launch {
            try {
                val response = RetrofitInstance.api.getAllCountries()
                _countries.addAll(response)
                Log.d("CountryViewModel", "Countries fetched: ${_countries.size}")
            } catch (e: Exception) {
                Log.e("CountryViewModel", "Error fetching countries", e)
                // Manejo de errores (mostrar un mensaje o un estado de error)
            }
        }
    }

    private val auth: FirebaseAuth = Firebase.auth
    private val _estadoLogin = MutableStateFlow(false)
    val estadoLogin: StateFlow<Boolean> = _estadoLogin



    fun hacerLoginGoogle(credencial: AuthCredential, home: () -> Unit) =
        viewModelScope.launch {
            try {
                auth.signInWithCredential(credencial)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            println("Login con Google, EXITOSO")
                            home()
                        }
                    }
                    .addOnFailureListener {
                        println("ERROR al hacer login con Google")
                    }
            } catch (e: Exception) {
                println("EXCEPCIÓN al hacer login: ${e.localizedMessage}")
            }
        }

    fun setEsatdoLogin(nuevoEstado: Boolean) {
        _estadoLogin.value = nuevoEstado
    }

    fun hacerLogoutGoogle() {
        auth.signOut()
        _estadoLogin.value = false
    }
}
