package com.chr.tarea5.view

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.chr.tarea5.viewmodel.ViewModelPaises
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider

@Composable
fun Login(viewModelPaises: ViewModelPaises = viewModel(), modifier: Modifier = Modifier) {


    val token = "287110946212-34u3ft7lkpinrjj9ivkoodlp24sa7fje.apps.googleusercontent.com"
    val contexto = LocalContext.current

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        val task = GoogleSignIn.getSignedInAccountFromIntent(it.data)
        try {
            val cuenta = task.getResult(ApiException::class.java)
            val credencial = GoogleAuthProvider.getCredential(cuenta.idToken, null)
            viewModelPaises.hacerLoginGoogle(credencial) {
                viewModelPaises.setEsatdoLogin(true)
            }
        } catch(e: Exception) {
            println("EXEPCION haciendo Login: ${e.localizedMessage}")
        }
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier.fillMaxSize().background(Color.LightGray)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Pantalla de LOGIN")
            Button(onClick = {
                val opciones = GoogleSignInOptions.Builder(
                    GoogleSignInOptions.DEFAULT_SIGN_IN
                ).requestIdToken(token)
                    .requestEmail()
                    .build()
                val clienteGoogle = GoogleSignIn.getClient(contexto, opciones)
                launcher.launch(clienteGoogle.signInIntent)
            }) {
                Text("Login con Google")
            }
        }
    }
}