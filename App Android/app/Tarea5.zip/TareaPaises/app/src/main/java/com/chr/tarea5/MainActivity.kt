package com.chr.tarea5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import com.chr.tarea5.ui.theme.Tarea5Theme
import com.chr.tarea5.view.AppPaises
import com.chr.tarea5.view.Login
import com.chr.tarea5.viewmodel.ViewModelPaises

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Tarea5Theme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    //AppPaises()
                    AppGeneral()
                }
            }
        }
    }
}

@Composable
fun AppGeneral(publicacionesVM: ViewModelPaises = viewModel()) {
    val estadoLogin = publicacionesVM.estadoLogin.collectAsState()

    if (estadoLogin.value) {
        AppPaises()
    } else {
        Login()
    }
}