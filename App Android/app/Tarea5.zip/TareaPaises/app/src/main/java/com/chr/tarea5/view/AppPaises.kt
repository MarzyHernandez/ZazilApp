package com.chr.tarea5.view

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.chr.tarea5.viewmodel.ViewModelPaises

/**
 * Función principal que configura la navegación entre pantallas de la app.
 * @author Carlos Herrera
 */
@Composable
fun AppPaises() {
    val navController = rememberNavController()
    val viewModel: ViewModelPaises = viewModel()

    NavHost(navController = navController, startDestination = "countryList") {
        composable("countryList") {
            CountryListScreen(viewModel = viewModel, navController = navController)
        }
        composable("countryDetail/{countryName}") { backStackEntry ->
            val countryName = backStackEntry.arguments?.getString("countryName")
            val country = viewModel.countries.find { it.name.common == countryName }
            country?.let {
                CountryDetailScreen(country = it, navController = navController)
            }
        }
    }
}
