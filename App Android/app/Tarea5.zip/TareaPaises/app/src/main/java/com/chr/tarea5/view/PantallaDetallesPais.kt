package com.chr.tarea5.view

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.rememberImagePainter
import com.chr.tarea5.model.Country

/**
 * Muestra los detalles de un país seleccionado, incluyendo su bandera, población y lenguajes.
 * Incluye un botón para regresar a la lista de países.
 * @param country Información del país seleccionada
 * @param navController Controlador de navegación para cambiar entre pantallas
 * @author Carlos Herrera
 */

@Composable
fun CountryDetailScreen(country: Country, navController: NavHostController) {
    Column(modifier = Modifier.padding(16.dp)) {
        Image(
            painter = rememberImagePainter(country.flags.png),
            contentDescription = "Flag of ${country.name.common}",
            modifier = Modifier.fillMaxWidth().height(200.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "País: ${country.name.common}")
        Text(text = "Población: ${country.population}")
        Text(text = "Idiomas: ${country.languages.values.joinToString(", ")}")

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.popBackStack() }) {
            Text(text = "Regresar")
        }
    }
}
