package com.chr.tarea5.model

// CountryApiService.kt (Interfaz de Retrofit)
import retrofit2.http.GET

// RetrofitInstance.kt (Instancia de Retrofit)
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

interface CountryApiService {
    @GET("v3.1/all")
    suspend fun getAllCountries(): List<Country>
}

object RetrofitInstance {
    private const val BASE_URL = "https://restcountries.com/"

    val api: CountryApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CountryApiService::class.java)
    }
}