package com.chr.tarea5.view

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.chr.tarea5.model.Country
import com.chr.tarea5.viewmodel.ViewModelPaises
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions

/**
 * Pantalla que muestra la lista de países obtenidos del ViewModel.
 * @param viewModel El ViewModel que maneja los datos de los países
 * @param navController Controlador de navegación para cambiar entre pantallas
 * @author Carlos Herrera
 */
@Composable
fun CountryListScreen(viewModel: ViewModelPaises, navController: NavController) {
    val countryList = viewModel.countries

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Botón de Logout en la parte superior
        Button(
            onClick = { viewModel.hacerLogoutGoogle() },
            modifier = Modifier.align(Alignment.End).padding(bottom = 16.dp)
        ) {
            Text(text = "Logout")
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(countryList) { country ->
                CountryItem(
                    country = country,
                    onClick = {
                        navController.navigate("countryDetail/${country.name.common}")
                    }
                )
            }
        }
    }
}


/**
 * Elemento que representa un país en la lista.
 * @param country Información del país
 * @param onClick Acción a ejecutar cuando se selecciona un país
 */
@Composable
fun CountryItem(country: Country, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Image(
            painter = rememberImagePainter(country.flags.png),
            contentDescription = "Bandera de: ${country.name.common}",
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(text = country.name.common, fontWeight = FontWeight.Bold)
            Text(text = "Población: ${country.population}")
        }
    }
}