package com.chr.tarea5.model
/**
 * Representa un país con su nombre, bandera, población y lenguajes.
 * @author Carlos Herrera
 */
data class Country(
    val name: Nombre,
    val flags: Banderas,
    val population: Long,
    val languages: Map<String, String>
)

/**
 * Representa el nombre de un país.
 * @author Carlos Herrera
 */
data class Nombre(
    val common: String
)

/**
 * Representa las banderas de un país en formato PNG.
 * @author Carlos Herrera
 */
data class Banderas(
    val png: String
)
